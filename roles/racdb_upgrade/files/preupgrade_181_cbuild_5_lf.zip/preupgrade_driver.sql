Rem
Rem $Header: rdbms/admin/preupgrade_driver.sql raeburns_bug-27523800_18.1.0.0.0/1 2018/03/13 07:41:49 raeburns Exp $
Rem
Rem preupgrade_driver.sql
Rem
Rem Copyright (c) 2011, 2018, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      preupgrade_driver.sql - Script used to load and execute the pre upgrade checks.
Rem
Rem    DESCRIPTION
Rem      Loads preupgrade_package.sql (defines the dbms_preup package) and then
Rem      makes calls to the pre-upgrade package functions to determine
Rem      the status of the to-be-upgraded database.
Rem
Rem      Accepts two optional arguments:
Rem
Rem      @preupgrade_driver {TERMINAL|FILE} {TEXT|XML} {EXEC|LOAD}
Rem
Rem         TERMINAL = Output goes to the default output device
Rem         FILE     = Output goes to file named
Rem                      for CDB$ROOT or non-CDB traditional DB: preupgrade.log
Rem                      for PDB: preupgrade_<pdbname>.log
Rem         TEXT = Generate normal text output
Rem         XML  = Generate an XML document (for DBUA use)
Rem 		EXEC = Execute DBMS_PREUP package
Rem 		LOAD = Only load DBMS_PREUP package
Rem 		
Rem   For example, to have the text output go to the screen:
Rem
Rem     @preupgrade_driver TERMINAL TEXT EXEC
Rem
Rem    NOTES
Rem
Rem      This driver runs the preupgrade ONLY for the currently selected DB or PDB.
Rem      It does not attempt to iterate through a group of PDBs.  The containing
Rem      preupgrade.jar file can be invoked to do that.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/preupgrade_driver.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/preupgrade_driver.sql 
Rem    SQL_PHASE: UTILITY
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    raeburns    03/07/18 - XbranchMerge raeburns_bug-27523800 from main
Rem    raeburns    02/20/18 - Bug 27523800: remove dbms_registry_basic from
Rem                           preupgrade.jar
Rem    bymotta     05/02/17 - Bug 25960926 - INCORRECT ENVIRONMENT SETTING
Rem    raeburns    03/17/17 - Bug 25616909: Use UTILITY for SQL_PHASE
Rem    bymotta     06/17/16 - Bug 22818326 adding load only capability to preupgrade.
Rem    bymotta     05/20/16 - Bug 23278082: Add null management on a query that
Rem                           as of 12.2 will not return any value
Rem    bymotta     03/03/16 - Bugs 22818326,22817008 upgrade.xml incomplete due
Rem                           missing privileges on directories.
Rem    ewittenb    09/18/15 - do not turn on TERMOUT or FEEDBACK
Rem    bymotta     09/01/15 - Adding functionality to preupgrade driver
Rem    ewittenb    04/15/15 - initial port from preupgrd.sql
Rem

SET FEEDBACK OFF
SET TERMOUT OFF
SET SERVEROUTPUT OFF

var error varchar2(250);

Rem Adding NLS_TERRITORY Settings to keep compatibility among 
Rem Charactersets and formats.
alter session set  nls_territory='america';

Rem
Rem    Establish _ORACLE_SCRIPT for version 12+ databases
Rem
VARIABLE majorvernum NUMBER;
BEGIN
    :majorvernum := 0;
    EXECUTE IMMEDIATE 'select to_number(substr(version,1,instr(version,''.'')-1))
        from v$instance' INTO :majorvernum;
    IF :majorvernum >= 12 THEN
        EXECUTE IMMEDIATE 'alter session set "_ORACLE_SCRIPT" = true';
    END IF;
END;
/

REM
REM    Preupgrade return status.
REM    0 = success, 1 = failure
REM    default to failure until we've got a clean success
REM
VARIABLE exit_status NUMBER
exec :exit_status := 1;

REM
REM   Fake as though parameters were passed if they
REM   were omitted by the user
REM   See header for more information about the parameters
REM
COLUMN 1 NEW_VALUE 1
COLUMN 2 NEW_VALUE 2
COLUMN 3 NEW_VALUE 3
SELECT '' "1", '' "2", '' "3" FROM SYS.DUAL WHERE ROWNUM = 0;
-- define 1
-- define 2
-- define 3

REM
REM   APPLY PARAMETER DEFAULTS.  FILE, TEXT and EXEC
REM
SELECT UPPER(NVL('&&1','FILE')) "1", UPPER(NVL('&&2','TEXT')) "2", UPPER(NVL('&&3','EXEC')) "3" FROM SYS.DUAL;
-- define 1
-- define 2
-- define 3

SET SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED TAB OFF;
SET ECHO OFF FEEDBACK OFF PAGESIZE 0 LINESIZE 32767;

Rem
Rem    Check if DBMS_PREUP exists -- this is to check STANDBY databases in READ ONLY mode.
Rem
VARIABLE countPackage number;
BEGIN
    :countPackage  := 0;
    EXECUTE IMMEDIATE 'select count(1) from dba_objects where object_type=''PACKAGE'' and
        object_name=''DBMS_PREUP''' INTO :countPackage;
END;
/

Rem
Rem    Check if DB is in READ status. If the DB is not in READ ONLY status
Rem    then it will set DBMS_REGISTRY_EXTENDED and PREUPGRADE_PACKAGE files
Rem    to be executed, else driver will not execute nothing.
Rem
VARIABLE DBMS_REGISTRY_EXTENDED VARCHAR2(100)
COLUMN :DBMS_REGISTRY_EXTENDED NEW_VALUE DBMS_REGISTRY_EXTENDED NOPRINT
VARIABLE PREUPGRADE_PACKAGE VARCHAR2(100)
COLUMN :PREUPGRADE_PACKAGE  NEW_VALUE PREUPGRADE_PACKAGE  NOPRINT
DECLARE
    status varchar2(100) :='';  
    object_not_found          EXCEPTION;
    PRAGMA EXCEPTION_INIT (object_not_found, -4043);
BEGIN
    :DBMS_REGISTRY_EXTENDED := dbms_registry.nothing_script; --Initialize values to nothing
    :PREUPGRADE_PACKAGE := dbms_registry.nothing_script;
    EXECUTE IMMEDIATE 'select OPEN_MODE from v$database' INTO status;
    IF status != 'READ ONLY'  THEN
        :DBMS_REGISTRY_EXTENDED := 'dbms_registry_extended.sql';
        :PREUPGRADE_PACKAGE := 'preupgrade_package.sql';
        if  :countPackage = 1 then
                execute immediate 'drop package dbms_registry_extended';
        end if;
    END IF;
    EXCEPTION WHEN object_not_found THEN
        NULL;
END;
/

select :DBMS_REGISTRY_EXTENDED from dual;
@@&dbms_registry_extended

select :preupgrade_package from dual;
@@&preupgrade_package

SET TERMOUT ON


declare
    output_filename VARCHAR2(500);
    is_xml BOOLEAN;
    check_count NUMBER;
    preupgrade_is_success BOOLEAN;
    con_name VARCHAR2(128);
begin
    dbms_preup.debug := false;

    is_xml := ('&&2' = 'XML');

    IF '&&1' = 'FILE' THEN
        IF is_xml THEN
            output_filename := 'upgrade.xml';
        ELSE
            output_filename := 'preupgrade.log';
        END IF;
        IF dbms_preup.db_is_cdb THEN
            EXECUTE IMMEDIATE 'select dbms_preup.get_con_name FROM sys.dual'
                into con_name;
                IF is_xml THEN
                    output_filename := 'upgrade_' || replace(con_name,'$','_') || '.xml';
                ELSE
                    output_filename := 'preupgrade_' || replace(con_name,'$','_') || '.log';
                END IF;
        END IF;
    ELSE
        output_filename := '';
    END IF;
    --
    --    run the preupgrade on this db/pdb only.
    --    Success does not refer to whether
    --    issues were identified with the underlying database
    --    but rather that this tool itself ran from
    --    start to finish and did not encounter
    --    something it couldn't recover from.
    --
    IF '&&3' = 'EXEC' THEN
        preupgrade_is_success := dbms_preup.run_preupgrade(output_filename, is_xml);
    ELSE
        preupgrade_is_success := TRUE;
    END IF;

    IF (preupgrade_is_success) THEN --and not con_name ='CDB$ROOT') THEN  -- < for unit testing
        :exit_status := 0;  --if sqlplus is running directly from java
    ELSE
	:exit_status := 1;  -- if sqlplus is running directly from java
    	IF dbms_preup.db_is_cdb THEN
	        dbms_output.put_line('error in '||con_name); -- if java is using catcon and is cdb.
        ELSE
	        dbms_output.put_line('error');
	    END IF;
    END IF;
    EXCEPTION WHEN OTHERS THEN      -- If the catch-all code on DBMS_PREUP raise an error
      dbms_output.put_line(dbms_utility.format_error_backtrace);  -- Print it and re-raise it
      raise;    
end;
/

Rem
Rem    Undo _ORACLE_SCRIPT
Rem
BEGIN
    IF :majorvernum >= 12 THEN
        EXECUTE IMMEDIATE 'alter session set "_ORACLE_SCRIPT" = false';
    END IF;
END;
/



--exit :exit_status

